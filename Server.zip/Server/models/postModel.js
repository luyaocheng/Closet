var mongoose = require('mongoose')

module.exports = mongoose.model('posts', {
	// authorName	: String,
	// talkMode 	: String,
	// postTime	: String,
	// postCat		: String,
	// postBody	: String,
	// postLikes	: Number,
	// postComments: String
})