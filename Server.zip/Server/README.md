# Closet
Project closet 

# Useful Links

**Classic nodejs server app code structure guideline**:  
http://stackoverflow.com/questions/5178334/folder-structure-for-a-node-js-project
